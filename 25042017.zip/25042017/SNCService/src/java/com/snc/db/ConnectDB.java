/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package com.snc.db;

import java.sql.Connection;
import java.sql.DriverManager;

/**
 *
 * @author nishant.vibhute
 */
public class ConnectDB {
     Connection con;
    String url;

    public Connection getConnection() {
        try {
            url = ("jdbc:mysql://localhost:3306/snc");
            Class.forName("com.mysql.jdbc.Driver");
            this.con = DriverManager.getConnection(url, "root", "root");
            return con;

        } catch (Exception e) {
            System.out.println(e);
        }
        return null;

    }

    public void closeConnection(Connection con) {
        try {
            if (con != null) {
                con.close();
            }

        } catch (Exception e) {
            System.out.println(e);
        }
    }
}
