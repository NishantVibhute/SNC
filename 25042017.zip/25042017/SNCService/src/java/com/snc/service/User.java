/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.snc.service;

import com.snc.bean.UserBean;
import com.snc.dao.Queries;
import java.io.IOException;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.UriInfo;
import javax.ws.rs.PathParam;
import javax.ws.rs.Consumes;
import javax.ws.rs.PUT;
import javax.ws.rs.Path;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Produces;
import org.codehaus.jackson.map.ObjectMapper;

/**
 * REST Web Service
 *
 * @author nishant.vibhute
 */
@Path("user")
public class User {

    Queries queries = new Queries();

    @POST
    @Produces("text/plain")
    @Path("/register")
    public String register(String content) {
        try {
            UserBean userBean;
            ObjectMapper objectMapper = new ObjectMapper();
            userBean = objectMapper.readValue(content, UserBean.class);
            queries.register(userBean);
        } catch (IOException ex) {
            Logger.getLogger(User.class.getName()).log(Level.SEVERE, null, ex);
        }
        return "success";
    }
    
    
    @GET
    @Produces("text/plain")
    @Path("/listUser")
    public String list(String content) {
        String list = null;
        try {
             ObjectMapper objectMapper = new ObjectMapper();
            ArrayList<UserBean> userList= new ArrayList();
           userList= queries.ListUser();
          list= objectMapper.writeValueAsString(userList);
           
        } catch (Exception ex) {
            Logger.getLogger(User.class.getName()).log(Level.SEVERE, null, ex);
        }
        return list;
    }

}
