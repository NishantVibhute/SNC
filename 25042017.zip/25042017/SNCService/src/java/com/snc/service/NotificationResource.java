/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.snc.service;

import com.snc.bean.Data;
import com.snc.bean.MessageBody;
import com.snc.bean.SendToBean;
import java.io.DataOutputStream;
import java.io.IOException;
import java.io.OutputStreamWriter;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.UriInfo;
import javax.ws.rs.PathParam;
import javax.ws.rs.Consumes;
import javax.ws.rs.PUT;
import javax.ws.rs.Path;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Produces;
import org.codehaus.jackson.map.ObjectMapper;

/**
 * REST Web Service
 *
 * @author nishant.vibhute
 */
@Path("notification")
public class NotificationResource {

    @POST
    @Produces("text/plain")
    @Consumes("text/plain")
    @Path("send")
    public String send(String content) {
        try {
            ObjectMapper objectMapper = new ObjectMapper();
            SendToBean sendToBean = new SendToBean();
            sendToBean = objectMapper.readValue(content, SendToBean.class);
            
            
            String targetURL = "https://fcm.googleapis.com/fcm/send";
            String key = "AIzaSyAOq45Ai7LNsuhxWDWn521jraGKkwwWNtE";
            String token = sendToBean.getToken();
            URL url = new URL(targetURL);
            HttpURLConnection con = (HttpURLConnection) url.openConnection();
            con.setRequestMethod("POST");
            con.setRequestProperty("Authorization", "key=" + key);
            con.setRequestProperty("Content-Type", "application/json");
con.setDoOutput(true);
            Data d = new Data();
            d.setMessage(sendToBean.getMessage());
            MessageBody msg = new MessageBody();
            msg.setD(d);
            msg.setTo(token);

            OutputStreamWriter wr = new OutputStreamWriter(con.getOutputStream());
            wr.write(objectMapper.writeValueAsString(msg));
            wr.flush();
            con.getInputStream();

            int responseCode = con.getResponseCode();

        } catch (Exception ex) {
            Logger.getLogger(NotificationResource.class.getName()).log(Level.SEVERE, null, ex);
        }
        return null;
    }
}
