/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package com.snc.dao;

import com.snc.bean.UserBean;
import com.snc.db.ConnectDB;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author nishant.vibhute
 */
public class Queries {
    ConnectDB db = new ConnectDB();
    Connection con;
    public void register(UserBean userBean)
    {
        try {
            this.con = db.getConnection();
            PreparedStatement ps = this.con.prepareStatement("insert into user_token(user_name,token) values(?,?)");
            ps.setString(1, userBean.getUserName());
            ps.setString(2, userBean.getUserToken());
                        ps.executeUpdate();
            db.closeConnection(con);
        } catch (SQLException ex) {
            Logger.getLogger(Queries.class.getName()).log(Level.SEVERE, null, ex);
        }
        
        
    }
    
    
    public ArrayList ListUser()
    {
        ArrayList<UserBean> userList = new ArrayList();
        try {
            this.con = db.getConnection();
            PreparedStatement ps = this.con.prepareStatement("Select * from user_token");
            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                UserBean ub = new UserBean();
                ub.setId(rs.getInt("id"));
                ub.setUserName(rs.getString("user_name"));
                ub.setUserToken(rs.getString("token"));
                userList.add(ub);
            }
            
            
            db.closeConnection(con);
        } catch (SQLException ex) {
            Logger.getLogger(Queries.class.getName()).log(Level.SEVERE, null, ex);
        }
        return userList;
      }
    
    
  
    
}
