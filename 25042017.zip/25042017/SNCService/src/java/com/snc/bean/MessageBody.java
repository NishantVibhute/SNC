/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package com.snc.bean;

/**
 *
 * @author nishant.vibhute
 */
public class MessageBody {
    Data d = new Data();
    String to;

    public Data getD() {
        return d;
    }

    public void setD(Data d) {
        this.d = d;
    }

    public String getTo() {
        return to;
    }

    public void setTo(String to) {
        this.to = to;
    }
    
    
    
}
