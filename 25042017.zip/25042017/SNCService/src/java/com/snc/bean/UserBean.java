/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package com.snc.bean;

import org.codehaus.jackson.annotate.JsonIgnore;


/**
 *
 * @author nishant.vibhute
 */
public class UserBean {
    @JsonIgnore
    public int id;
    public String userName;
    public String userToken;

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getUserName() {
        return userName;
    }

    public void setUserName(String userName) {
        this.userName = userName;
    }

    public String getUserToken() {
        return userToken;
    }

    public void setUserToken(String userToken) {
        this.userToken = userToken;
    }
    
     
}
